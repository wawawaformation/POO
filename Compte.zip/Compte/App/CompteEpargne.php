<?php
require __DIR__ . '/Compte.php';

/**
 * REprésente un compte épargne (une histoire d'interet)
 */
class CompteEpargne extends Compte
{

    /**
     * Taux d'intérêt
     * @var float
     */
    static public float $tauxInteret = 1.03;


    /**
     * Verser des intérêts
     * @return CompteEpargne
     */
    public function verserInterets(): self
    {
        $this->setSolde($this->solde * self::$tauxInteret);
        return $this;
    }
}