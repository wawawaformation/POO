<?php

require_once __DIR__ . '/Compte.php';
class CompteCourant extends Compte
{
    protected int $decouvertAutorise = 0;


    /**
	 * Modifie le Solde du compte
	 * @param float $solde Solde du compte
	 * @return self
	 */
	public function setSolde(float $solde): self 
    {
        if($solde < -1*$this->decouvertAutorise) {
            trigger_error('Le solde ne peut être inférieur au découvert autorisé', E_USER_ERROR);
        }
		$this->solde = $solde;
		return $this;
	}

    

	/**
	 * @return int
	 */
	public function getDecouvertAutorise(): int {
		return $this->decouvertAutorise;
	}
	
	/**
	 * @param int $decouvertAutorise 
	 * @return self
	 */
	public function setDecouvertAutorise(int $decouvertAutorise): self {
		$this->decouvertAutorise = $decouvertAutorise;
		return $this;
	}
}

