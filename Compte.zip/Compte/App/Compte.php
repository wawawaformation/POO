<?php

/**
 * Représente un compte bancaire
 */
abstract class Compte
{
    /**
     * Titulaire du compte
     * @var string
     */
    protected string $titulaire;

    /**
     * Solde du compte
     * @var float
     */
    protected float $solde;



    /**
     * Instancie la place
     * @param string $titulaire le titualire du compte
     * @param float $solde le solde initial
     */
    public function __construct(string $titulaire, float $solde){
        $this->setSolde($solde);
        $this->setTitulaire($titulaire);
    }
    

    /**
     * REtirer des sous
     * @param float $somme somme à retirer
     * @return Compte
     */
    public function retirer(float $somme): self
    {
        $this->setSolde($this->solde - $somme);
        return $this;
    }


    /**
     * Faire un virement de son compte à un autre
     * @param Compte $compte compte sur lequel on vire de l'argent
     * @param float $somme somme à transférer
     * @return void
     */
    public function virer(Compte $compte, float $somme): void
    {
        $this->retirer($somme);
        $compte->deposer($somme);

    }
    /**
     * Déposer des sous
     * @param float $somme somme à déposer
     * @return Compte
     */
    public function deposer(float $somme): self{
        $this->setSolde($this->solde + $somme);
        return $this;
    }

	/**
	 * REtourne Titulaire du compte
	 * @return string le titualire
	 */
	public function getTitulaire(): string {
		return $this->titulaire;
	}
	
	/**
	 * Modifie Titulaire du compte
	 * @param string $titulaire Titulaire du compte
	 * @return self
	 */
	public function setTitulaire(string $titulaire): self 
    {
        if(empty($titulaire)) {
            trigger_error('Le nom ne peut être vide',E_USER_ERROR);
        }
		$this->titulaire = $titulaire;
		return $this;
	}

	/**
	 * REtourn le Solde du compte
	 * @return float
	 */
	public function getSolde(): 
    float {
		return $this->solde;
	}
	
	/**
	 * Modifie le Solde du compte
	 * @param float $solde Solde du compte
	 * @return self
	 */
	public function setSolde(float $solde): self 
    {
        if($solde < 0) {
            trigger_error('Le solde ne peut être négatif', E_USER_ERROR);
        }
		$this->solde = $solde;
		return $this;
	}
}