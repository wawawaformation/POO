<?php

require_once __DIR__ .'/App/CompteEpargne.php';

$epargne = new CompteEpargne('david',100);

var_dump($epargne->verserInterets());



